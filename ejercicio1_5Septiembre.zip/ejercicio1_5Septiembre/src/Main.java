public class Main {

    public static void metodoAnashe(String nombre) throws Exception{
        System.out.println("El nombre es: " + nombre.length());
    }

    public static void largo(){
        String nombre = null;
        try{
            if(nombre == null){
                throw new Exception("El valor es nulo");
            }
            System.out.println("El nombre es: " + nombre.length());

        }
        catch (Exception e){
            e.getMessage();
        }
    }

    public void nulo(String nombre) throws NombreNuloException {
        if (nombre == null){
            throw new NombreNuloException("El valo es nulo");
        }
    }
    public static void main(String[] args) {
       /* String nombre = null;
       try{
            System.out.println("El nombre es: " + nombre.length());
        }
        catch (Exception e){
            System.out.println("El valor es nulo");
        }
        */

        /*
        largo();
         */


       /* try {
            metodoAnashe(null);
        }
        catch (Exception e){
            System.out.println("El valor es nulo");
        }
        */
        
        Main main = new Main();
        try{
            main.nulo(null);
        } catch(NombreNuloException e){
            e.printStackTrace();
            e.getMessage();
        }

    }
}
