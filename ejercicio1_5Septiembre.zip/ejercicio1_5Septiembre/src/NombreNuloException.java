public class NombreNuloException extends Exception{
    public NombreNuloException(String mensaje){
        super(mensaje);
    }
}
