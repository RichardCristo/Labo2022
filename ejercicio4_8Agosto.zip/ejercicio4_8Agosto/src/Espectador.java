public class Espectador {
    private String nombre;
    private int edad;
    private float plata;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public float getPlata() {
        return plata;
    }

    public void setPlata(float plata) {
        this.plata = plata;
    }

    public Espectador() {
        this.nombre = nombre;
        this.edad = edad;
        this.plata = plata;
    }
}
