public class Pelicula {
    private String titulo;
    private float duracion;
    private int edad_minima;
    private String directar;

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public float getDuracion() {
        return duracion;
    }

    public void setDuracion(float duracion) {
        this.duracion = duracion;
    }

    public int getEdad_minima() {
        return edad_minima;
    }

    public void setEdad_minima(int edad_minima) {
        this.edad_minima = edad_minima;
    }

    public String getDirectar() {
        return directar;
    }

    public void setDirectar(String directar) {
        this.directar = directar;
    }

    public Pelicula() {
        this.titulo = titulo;
        this.duracion = duracion;
        this.edad_minima = edad_minima;
        this.directar = directar;
    }
}
