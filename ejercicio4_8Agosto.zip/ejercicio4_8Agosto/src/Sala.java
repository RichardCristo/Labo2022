import java.util.ArrayList;

public class Sala {
    private Pelicula pelicula;
    private float precio_entrada;
    private ArrayList<ArrayList<boolean>> asientos;

}
