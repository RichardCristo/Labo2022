public abstract class Pantalon extends Ropa {
    private double medidaCintura;
    private double medidaCadera;
    private double medidaLargo;

    public Pantalon(double medidaCintura, double medidaCadera, double medidaLargo) {
        this.medidaCintura = medidaCintura;
        this.medidaCadera = medidaCadera;
        this.medidaLargo = medidaLargo;
    }

    public double getMedidaCintura() {
        return medidaCintura;
    }

    public void setMedidaCintura(double medidaCintura) {
        this.medidaCintura = medidaCintura;
    }

    public double getMedidaCadera() {
        return medidaCadera;
    }

    public void setMedidaCadera(double medidaCadera) {
        this.medidaCadera = medidaCadera;
    }

    public double getMedidaLargo() {
        return medidaLargo;
    }

    public void setMedidaLargo(double medidaLargo) {
        this.medidaLargo = medidaLargo;
    }


}
