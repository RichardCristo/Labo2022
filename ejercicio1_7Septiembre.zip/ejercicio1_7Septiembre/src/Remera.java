public abstract class Remera extends Ropa{
    private double medidaEspalda;
    private double medidaContorno;
    private double largoTorso;

    public Remera(double medidaEspalda, double medidaContorno, double largoTorso) {
        this.medidaEspalda = medidaEspalda;
        this.medidaContorno = medidaContorno;
        this.largoTorso = largoTorso;
    }

    public double getMedidaEspalda() {
        return medidaEspalda;
    }

    public void setMedidaEspalda(double medidaEspalda) {
        this.medidaEspalda = medidaEspalda;
    }

    public double getMedidaContorno() {
        return medidaContorno;
    }

    public void setMedidaContorno(double medidaContorno) {
        this.medidaContorno = medidaContorno;
    }

    public double getLargoTorso() {
        return largoTorso;
    }

    public void setLargoTorso(double largoTorso) {
        this.largoTorso = largoTorso;
    }


}
