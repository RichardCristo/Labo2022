import java.time.LocalDate;

public interface Prestable {
    void prestar();

    void agregarElemento();

}
