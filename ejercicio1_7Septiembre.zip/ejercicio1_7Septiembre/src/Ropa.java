public abstract class Ropa implements Prestable {
    private String color;
    private String material;
    private boolean estado;

    public Ropa() {
        this.color = color;
        this.material = material;
        this.estado = estado;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public boolean getEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public boolean sePuedePrestar(){
        if(!this.estado) return false;
        else return true;
    }

    @Override
    public void prestar(){
        if(!this.sePuedePrestar()) System.out.println("La ropa no se puede prestar");
        else System.out.println("La ropa se puede prestar");
    }

    @Override
    public void agregarElemento(){
        if(!sePuedePrestar()) System.out.println("El articulo ingresado puede entrar al circuito de prestamos");
        else System.out.println("El articulo ingresado no puede entrar al circuito de prestamos");
    }
}
