import java.time.LocalDate;
import java.util.Date;

public abstract class Revista extends Libreria implements Prestable {
    private LocalDate fechaPublicacion;

    public Revista(LocalDate fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

    public LocalDate getFechaPublicacion() {
        return fechaPublicacion;
    }

    public void setFechaPublicacion(LocalDate fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

    public boolean sePuedePrestarLaRevista(){
        if (this.fechaPublicacion.getMonth().compareTo(LocalDate.now().getMonth()) == -3) return true;
        else return false;
    }

    @Override
    public void prestar(){
        if (!sePuedePrestarLaRevista())System.out.println("La revista se puede prestar");
        else System.out.println("La revista no se puede prestar");
    }

    @Override
    public void agregarElemento() {
        if (!sePuedePrestarLaRevista()) System.out.println("El articulo ingresado puede entrar al circuito de prestamos");
        else System.out.println("El articulo ingresado no puede entrar al circuito de prestamos");
    }
}