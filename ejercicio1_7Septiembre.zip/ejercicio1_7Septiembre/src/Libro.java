import java.util.HashMap;

public abstract class Libro extends Libreria implements Prestable{
    private HashMap<Integer,Integer> cantidadDePaginasPorCapitulo;

    public Libro(HashMap<Integer, Integer> cantidadPaginas) {
        this.cantidadDePaginasPorCapitulo = cantidadPaginas;
    }

    public HashMap<Integer, Integer> getCantidadPaginas() {
        return cantidadDePaginasPorCapitulo;
    }

    public void setCantidadPaginas(HashMap<Integer, Integer> cantidadPaginas) {
        this.cantidadDePaginasPorCapitulo = cantidadPaginas;
    }

    public boolean sePuedePrestarElLibro(){
        boolean aux = true;
        for(int i : this.cantidadDePaginasPorCapitulo.keySet()){
            if(i%2 == 0) aux = true;
            else aux = false;
        }
        if(!aux) return false;
        else return true;
    }

   @Override
    public void prestar(){
        if(!sePuedePrestarElLibro()) System.out.println("El libro se puede prestar");
        else System.out.println("El libro no se puede prestar");
   }

   @Override
    public void agregarElemento(){
       if(!sePuedePrestarElLibro()) System.out.println("El articulo ingresado puede entrar al circuito de prestamos");
       else System.out.println("El articulo ingresado no puede entrar al circuito de prestamos");
   }

}
